package in.nimbo;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages user's storage size.
 */
public class UserStorageRepository {

    // Do not change this line!
    private Map<String, Integer> userStorageMap = new HashMap<>();

    /**
     * Increase storage of given user by given size. If given user does not exists, it creates the user.
     */
    public void increaseStorageOfUser(String user, int size) {
        //Your Code
    }

    /**
     * Check if user has at least given storage. If user does not exits false is returned.
     */
    public boolean hasStorage(String user, int size) {
        // Your Code
        return true;
    }

    /**
     * Decrease user storage by given size. If user does not have enough storage, should be deleted.
     */
    public void decreaseStorageOfUser(String user, int size) {
        //Your Code
    }
}
