public class SpamDetector {

    public SpamType[] detectSpams(Message[] messages) {
        //todo
    }

}